#include <iostream>
#include <fstream>
#include <string>

using namespace std;

// Registers a new user by saving username and password to file (plain text)
void registerUser() {
    string username, password;

    cout << "Enter a username: ";
    cin >> username;
    if (username.empty()) {
        cout << "Username cannot be empty.\n";
        return;
    }

    cout << "Enter a password: ";
    cin >> password;
    if (password.empty()) {
        cout << "Password cannot be empty.\n";
        return;
    }

    ofstream outFile("users.txt", ios::app);
    if (!outFile) {
        cout << "Error: Unable to open user database.\n";
        return;
    }

    // WARNING: Storing passwords in plain text is insecure.
    outFile << username << " " << password << endl;
    outFile.close();

    cout << "User registered successfully!\n";
}

// Logs in an existing user by checking stored credentials
bool loginUser() {
    string username, password, storedUser, storedPass;

    cout << "Enter username: ";
    cin >> username;
    cout << "Enter password: ";
    cin >> password;

    ifstream inFile("users.txt");
    if (!inFile) {
        cout << "Error: User database not found!\n";
        return false;
    }

    // Check if credentials match any line in the file
    while (inFile >> storedUser >> storedPass) {
        if (username == storedUser && password == storedPass) {
            cout << "Login successful!\n";
            inFile.close();
            return true;
        }
    }

    cout << "Invalid username or password.\n";
    inFile.close();
    return false;
}

// Displays the menu and handles user interaction
void showMenu() {
    int choice;
    while (true) {
        cout << "\n1. Register\n2. Login\n3. Exit\nChoose an option: ";
        cin >> choice;

        switch (choice) {
        case 1:
            registerUser();
            break;
        case 2:
            loginUser();
            break;
        case 3:
            cout << "Exiting program.\n";
            return;
        default:
            cout << "Invalid choice. Try again.\n";
        }
    }
}

int main() {
    showMenu();
    return 0;
}