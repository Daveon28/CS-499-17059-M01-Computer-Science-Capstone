#include <iostream>
#include <fstream>
#include <string>

using namespace std;

void registerUser() {
    string username, password;
    ofstream outFile("users.txt", ios::app); // Opens file in append mode

    cout << "Enter a username: ";
    cin >> username;
    cout << "Enter a password: ";
    cin >> password;

    // Store username and password (INSECURE: Plain text storage)
    outFile << username << " " << password << endl;
    outFile.close();

    cout << "User registered successfully!\n";
}

bool loginUser() {
    string username, password, u, p;
    ifstream inFile("users.txt");

    if (!inFile) { // Check if file exists
        cout << "Error: User database not found!\n";
        return false;
    }

    cout << "Enter username: ";
    cin >> username;
    cout << "Enter password: ";
    cin >> password;

    // Check credentials
    while (inFile >> u >> p) {
        if (u == username && p == password) {
            cout << "Login successful!\n";
            inFile.close();
            return true;
        }
    }

    cout << "Invalid username or password.\n";
    inFile.close();
    return false;
}

int main() {
    int choice;
    while (true) {
        cout << "\n1. Register\n2. Login\n3. Exit\nChoose an option: ";
        cin >> choice;

        switch (choice) {
        case 1:
            registerUser();
            break;
        case 2:
            loginUser();
            break;
        case 3:
            cout << "Exiting program.\n";
            return 0;
        default:
            cout << "Invalid choice. Try again.\n";
        }
    }
}
